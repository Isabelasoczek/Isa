// Variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;
let raio = diametro / 2;

// Variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0); // Limpa o fundo a cada frame

  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete();
  movimentaMinhaRaquete();
  verificaColisaoRaquete();
}

function mostraBolinha() {
  fill(255); // Define a cor da bolinha como branca
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda() {
  // Verifica colisões com as bordas horizontais
  if (xBolinha > width || xBolinha < 0) {
    velocidadeXBolinha *= -1; // Inverte a direção horizontal
  }

  // Verifica colisões com as bordas verticais
  if (yBolinha > height || yBolinha < 0) {
    velocidadeYBolinha *= -1; // Inverte a direção vertical
  }
}

function mostraRaquete() {
  fill(255); // Define a cor da raquete como branca
  rect(xRaquete, yRaquete, raqueteComprimento, raqueteAltura);
}

function movimentaMinhaRaquete() {
  if (keyIsDown(UP_ARROW)) {
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)) {
    yRaquete += 10;
  }
}

function verificaColisaoRaquete() {
  // Verifica colisão da bolinha com a raquete
  if (xBolinha - raio < xRaquete + raqueteComprimento && 
      xBolinha + raio > xRaquete && 
      yBolinha - raio < yRaquete + raqueteAltura && 
      yBolinha + raio > yRaquete) {
    velocidadeXBolinha *= -1;
  }
}

 
  
    <script src="ske

 

  












